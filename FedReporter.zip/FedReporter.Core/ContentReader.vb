﻿Imports System.IO

Public Class ContentReader
    Public Shared Function GetXmlDocument(filePath As String) As XDocument

        If Not File.Exists(filePath) Then   
            Throw New FileNotFoundException("File does not exist")
        End If

        Return XDocument.Load(filePath)
    End Function

    Public Shared Function GetElements(doc As XDocument, elementName As String) As IEnumerable(Of XElement)

        If doc Is Nothing Then
            Return XElement.EmptySequence()
        End If

        Return doc.Root.Descendants(elementName)
    End Function

    Public Shared Function GetAttributes(element As XElement, attributeName As String) As IEnumerable(Of XAttribute)

        If element Is Nothing Then
            Return XAttribute.EmptySequence()
        End If

        Return element.Attributes(attributeName)
    End Function
End Class
