﻿Public Class ElementRemover
    Public Shared Sub RemoveUnwantedElements(ByRef elements As IEnumerable(Of XElement), attributeName As String,
                                             unwantedText As String)

        For i As Integer = 0 To elements.count
            Dim xElement = elements(i)

            ' Getting attributes with name "{http://www.w3.org/1999/xlink}label"
            Dim labelAttributes = ContentReader.GetAttributes(xElement, attributeName)

            ' If element contains "RCFD", remove the element
            If HasUnwantedText(labelAttributes, unwantedText) Then
                xElement.Remove()
            End If
        Next
    End Sub

    Public Shared Function HasUnwantedText(attributes As IEnumerable(Of XAttribute), unwantedText As String) As Boolean

        '  Check that label contains "RCFD"
        Return attributes.Any(Function(attribute) _
                                 attribute.Value.IndexOf(unwantedText, StringComparison.Ordinal) > - 1)
    End Function
End Class
