Imports System.IO
Imports FedReporter.Core

Module Program
    ' INPUTS
    Private Const InputFile = "call-rr-2018-03-31-v161-ec.xml"
    Private Const FilePath = "your-file-path-here\FedReporter\FedReporter\Content\"

    ' PARAMS
    Const ElementName = "{http://www.ffiec.gov/2003/linkbase}loc"
    Const AttributeName = "{http://www.w3.org/1999/xlink}label"
    Const UnwantedText = "RCFD"

    Sub Main(args As String())

        ' Read file contents
        Console.WriteLine("Reading file: " + FilePath + InputFile)
        Dim xmlDocument = ContentReader.GetXmlDocument(FilePath + InputFile)

        ' Find file contents where element is <loc>
        Console.WriteLine("Getting xml elements with name: " + ElementName)
        Dim elements = ContentReader.GetElements(xmlDocument, ElementName)

        Console.WriteLine("Found " & elements.count & " elements with name: " & ElementName)
        Console.WriteLine("Getting element attributes with name: " + AttributeName)
        Console.WriteLine("Removing elements where label attributes contain: " + UnwantedText)
        ElementRemover.RemoveUnwantedElements(elements, AttributeName, UnwantedText)

        ' Output contents with "RCFD" elements removed
        Console.WriteLine("Saving cleaned file to: " & FilePath & "CLEANED---" & InputFile)
        xmlDocument.Save(FilePath & "CLEANED---" & InputFile)

        Console.WriteLine("Press any key to exit...")
        Console.ReadKey()
    End Sub
End Module
